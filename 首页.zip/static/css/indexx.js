document.writeln('<style>');
document.writeln('body,div,dl, dt, dd, ul, ol, li, h1, h2, h3, h4, h5, h6, pre, form, fieldset, input, textarea, p, blockquote {margin:0;padding:0;}');
document.writeln('ul,ul li{ list-style:none}');
document.writeln('#thead img{ border:0}');
document.writeln('#thead{ width:100%; height:43px; background:#fff;border-bottom:1px solid #e1e1e1; margin:0;padding:0;font-family:"Microsoft Yahei", Verdana, Arial, Helvetica, sans-serif; font-size:14px;color:#7d7c7c;}');
document.writeln('#thead a{font-family:"Microsoft Yahei", Verdana, Arial, Helvetica, sans-serif;font-size:14px;color:#7d7c7c; text-decoration:none}');
document.writeln('#thead a:hover{ color:#010101;font-family:"Microsoft Yahei", Verdana, Arial, Helvetica, sans-serif;}');
document.writeln('#thead .thead{ width:1200px; height:59px; margin:0 auto; position:relative; z-index:10000;}');
document.writeln('#thead .thead .tlogo{ width:84px; height:35px; position:absolute;top:3px;left:16px; z-index:1001}');
document.writeln('#Topbar_menu{ position:absolute;right:150px; text-align:right; z-index:101}');
document.writeln('#Topbar_menu span{ color:#010101;}');
document.writeln('#Topbar_menu a.menu{line-height:43px; height:43px;padding:0 10px; cursor:pointer; background:none; position:static}');
document.writeln('#all_menugame{width:150px; z-index:100;overflow:hidden; height:43px;position:absolute;top:0;right:0;}');
document.writeln('#all_menugame .menutitle{height:43px; line-height:43px;text-align:center;position:absolute;top:0;right:0; width:150px; z-index:101;transition:background 0.3s ease-in-out 0s; -moz-transition:background 0.3s ease-in-out 0s; -ms-transition:background 0.3s ease-in-out 0s;-o-transition:background 0.3s ease-in-out 0s;-webkit-transition:background 0.3s ease-in-out 0s;}');
document.writeln('#all_menugame .all_menugame_ico{ width:10px; height:6px; background:url(http://stc.kongzhong.com/kongzhong/images/head/top_ico.png) no-repeat; display:inline-block; vertical-align: middle;transition:all all 0.2s linear 0s}');
document.writeln('#all_menugame.all_menugame_hover{box-shadow:3px 0 8px rgba(0,0,0,.15);height:335px;transition:height 0.3s ease-in-out 0s; -moz-transition:height 0.3s ease-in-out 0s; -ms-transition:height 0.3s ease-in-out 0s;-o-transition:height 0.3s ease-in-out 0s;-webkit-transition:height 0.3s ease-in-out 0s;width:1000px;}');
document.writeln('#all_menugame.all_menugame_hover .all_menugame_ico{transform:rotate(180deg)}');
document.writeln('#all_menugame.all_menugame_hover .menutitle{color:#f90; background:#f0f0f0;}');
document.writeln('#all_menugame.all_menugame_hover .all_menugame_ico{ background-position:0 -6px;}');
document.writeln('#all_menugame_text{position:absolute;top:44px;right:0;width:1000px;height:auto;text-align:left;padding-top:10px;background:#fff;padding-bottom:20px; z-index:1000; line-height: 36px; color: #333; font-size: 14px; overflow: hidden;}');
document.writeln('#all_menugame_text a{color: #333;}');
document.writeln('#all_menugame_text a:hover{color: #ed6b00;}');
document.writeln('#all_menugame_text > div{min-height: 260px;}');
document.writeln('#all_menugame_text div,#all_menugame_text li{display: inline-block; float: left;}');
document.writeln('#all_menugame_text ul{margin-left: 40px;overflow: hidden;}');
document.writeln('#all_menugame_text h2,#all_menugame_text h3{width: 100%; text-align: center; font-size: 14px;}');
document.writeln('#all_menugame_text h2{line-height: 40px; color: #ed6b00; background: #f5f5f5;}');
document.writeln('#all_menugame_text h3{margin: 18px 0 10px; color: #333;}');
document.writeln('.pub-pcgames{width: 419px; border-right: solid 1px #eaeaea; overflow: hidden;}');
document.writeln('.pub-wgngames,.pub-mgames{width: 260px;}');
document.writeln('.pub-wgngames li,.pub-mgames li{min-width: 110px;}');
document.writeln('.pub-biggames,.pub-mall,.pub-gameads{border-left: solid 1px #eaeaea;}');
document.writeln('.pub-mgames ul,.pub-mall ul,.pub-gameads ul{margin-top: 30px;}');
document.writeln('.pub-biggames li,.pub-mall li,.pub-gameads li{min-width: 114px;}');
document.writeln('.pub-biggames{width: 158px;}');
document.writeln('.pub-mall,.pub-gameads{width: 159px;}');
document.writeln('#all_menugame_text .menugame_ico_hot,#all_menugame_text .menugame_ico_H,#all_menugame_text .menugame_ico_N{ background:url(http://stc.kongzhong.com/kongzhong/images/head/top_ico.png) no-repeat; display:inline-block; margin-left:3px;}');
document.writeln('#all_menugame_text .menugame_ico_hot{ width:12px; height:16px; background-position:0 -17px; vertical-align:middle}');
document.writeln('#all_menugame_text .menugame_ico_H,#all_menugame_text .menugame_ico_N{ width:11px; height:11px; vertical-align: middle;}');
document.writeln('#all_menugame_text .menugame_ico_H{ background-position:-21px -20px;}');
document.writeln('#all_menugame_text .menugame_ico_N{background-position:-43px -20px;}');
document.writeln('#all_menugame_text:after{clear: both;content:"";display: block;height:0;visibility: hidden;}');
document.writeln('#all_menuimg{ position:absolute;top:0;left:0;padding-left:120px;z-index:100; overflow:hidden; height:43px;}');
document.writeln('#all_menuimg div.smallImages {height: 4000px;overflow: hidden;width:500px;}');
document.writeln('#all_menuimg div.smallImages img {display: block;height: 43px;width: 500px;}');
document.writeln('#all_menuimg .bigpic {height: 194px;overflow: hidden; position: relative;width: 9800px;z-index: -10;}');
document.writeln('#all_menuimg .bigpic a {display: block;float: left;height: 194px;overflow: hidden;width:1200px;}');
document.writeln('#all_menuimg .bigpic img,#all_menuimg .bigpic a img {height: 194px;width:1200px;z-index: 0;}');
document.writeln('#all_menuimg.all_menuimg_hover{height:200px;transition:height 0.3s ease-in-out 0s; -moz-transition:height 0.3s ease-in-out 0s; -ms-transition:height 0.3s ease-in-out 0s;-o-transition:height 0.3s ease-in-out 0s;-webkit-transition:height 0.3s ease-in-out 0s;width:1170px;}');
document.writeln('#all_menuimg.all_menuimg_hover dd{ display:block}');
document.writeln('#all_menuimg dt{height:43px; width:auto;vertical-align:middle;}');
document.writeln('#all_menuimg dd{ display:none; width:1200px; height:auto;position:absolute; display:none;top:0;left:0; z-index:1000}');
document.writeln('#tfoot{ height:123px; width:100%; background:url(http://stc.kongzhong.com/kongzhong/images/head/tweibg.jpg) 0 -44px repeat-x;}');
document.writeln('#tfoot .bottom{width:980px;margin:0 auto;padding-top:25px;height:98px;overflow:hidden}');
document.writeln('#tfoot .blogo,#tfoot .blogo img,#tfoot .blogo a img,#tfoot .bcen{ float:left; display:inline}');
document.writeln('#tfoot .blogo{ width:152px; height:43px; border-right:1px solid #d6d6d6; margin:15px 0 0 65px;}');
document.writeln('#tfoot .blogo img,#tfoot .blogo a img{ margin-right:12px;}');
document.writeln('#tfoot .bcen{ width:760px; color:#999; text-align:left}');
document.writeln('#tfoot .bcen p{ height:20px; line-height:20px;text-indent:17px;}');
document.writeln('#tfoot .bcen p.text a.fliu{ margin:0 17px;}');
document.writeln('#tfoot .bcen p.text{ text-indent:0px; line-height:22px; height:22px;}');
document.writeln('#tfoot .bcen p a.fjiu{ margin-right:12px;}');
document.writeln('</style>');
document.writeln('<div id="thead">');
document.writeln('    <div class="thead">');
document.writeln('        <a href="http://www.kongzhong.com/" target="_blank" class="tlogo"><img src="http://stc.kongzhong.com/kongzhong/images/2016/h_logo.png"></a>');
document.writeln('        <dl id="all_menuimg" class="">');
document.writeln('            <dt style="display: block;">');
document.writeln('                <div class="smallImages">');

document.writeln('                <img src="http://img.kongzhong.com/wot/20200313/33460.jpg">');

document.writeln('                </div>');
document.writeln('            </dt>');
document.writeln('            <dd style="display: none;">');
document.writeln('                <div class="bigpic">');

document.writeln('                  <a style="display: none;" target="_blank" href="http://wg.360.cn/"><img src="http://img.kongzhong.com/wot/20200313/33461.jpg"></a>');




document.writeln('              </div>');
document.writeln('            </dd>');
document.writeln('        </dl>');
document.writeln('        <div id="Topbar_menu">');
document.writeln('            <div id="menulogin">');
document.writeln('                <a onclick="pubH_urljump()" class="menu">登录</a>');
document.writeln('                <a href="http://passport.kongzhong.com/acc.do?m=toRegPhone&amp;RegActionUrl=http%3A%2F%2Fpassport.kongzhong.com%2F" target="_blank" class="menu">注册</a>');
document.writeln('                <a href="http://mall.kongzhong.com/#001" target="_blank" class="menu">充值</a>');
document.writeln('                <a href="http://kf.kongzhong.com/" target="_blank" class="menu">客服</a>');
document.writeln('            </div>');
document.writeln('            <div id="jloginbox"></div>');
document.writeln('        </div>');
document.writeln('        <div id="all_menugame" class="">');
document.writeln('            <div class="menutitle">');
document.writeln('                空中网旗下产品');
document.writeln('                <em class="all_menugame_ico"></em>');
document.writeln('            </div>');
document.writeln('            <div id="all_menugame_text">');
document.writeln('                <div class="pub-pcgames">');
document.writeln('                    <h2>客户端游戏</h2>');
document.writeln('                    <div class="pub-wgngames">');
document.writeln('                        <h3>军武游戏</h3>');
document.writeln('                        <ul>');
document.writeln('                            <li><a target="_blank" href="http://zz.kongzhong.com/">装甲战争</a><i class="menugame_ico_H"></i></li>');
document.writeln('                            <li><a target="_blank" href="http://wot.kongzhong.com/">坦克世界</a><i class="menugame_ico_H"></i></li>');
document.writeln('                            <li><a target="_blank" href="http://wows.kongzhong.com/">战舰世界</a><i class="menugame_ico_H"></i></li>');
document.writeln('                            <li><a target="_blank" href="http://wowp.kongzhong.com/">战机世界</a></li>');
document.writeln('                        </ul>');
document.writeln('                    </div>');
document.writeln('                    <div class="pub-biggames">');
document.writeln('                        <h3>大型游戏</h3>');
document.writeln('                        <ul>');
document.writeln('                            <li><a target="_blank" href="http://gw2.kongzhong.com/">激战2</a><i class="menugame_ico_H"></i></li><li>&nbsp;</li><li>&nbsp;</li><li>&nbsp;</li>');
document.writeln('                        </ul>');
document.writeln('                    </div>');
document.writeln('                </div>');
document.writeln('                <div class="pub-mgames">');
document.writeln('                    <h2>手机游戏</h2>');
document.writeln('                    <div class="pub-hotgames">');
document.writeln('                        <ul>');
document.writeln('                            <li><a target="_blank" href="http://zjls.kongzhong.com/">战舰猎手</a><i class="menugame_ico_H"></i></li>');
document.writeln('                        </ul>');
document.writeln('                    </div>');
document.writeln('                </div>');
document.writeln('                <div class="pub-mall">');
document.writeln('                    <h2>商城</h2>');
document.writeln('                    <div class="pub-mallgames">');
document.writeln('                        <ul>');
document.writeln('                            <li><a target="_blank" href="http://mall.kongzhong.com/">军武游戏商城</a></li>');
document.writeln('                            <li><a target="_blank" href="http://awmall.kongzhong.com/">装甲商城</a></li>');
document.writeln('                            <li><a target="_blank" href="https://s.click.taobao.com/vOVCfLw">天猫旗舰店</a></li>');
document.writeln('                            <li><a target="_blank" href="http://kongzhong.jd.com/">京东旗舰店</a></li>');
document.writeln('                            <li><a target="_blank" href="https://kongzhong.tmall.com/p/rd866965.htm">军武周边</a></li>');
document.writeln('                        </ul>');
document.writeln('                    </div>');
document.writeln('                </div>');
document.writeln('                <div class="pub-gameads">');
document.writeln('                    <h2>游戏辅助</h2>');
document.writeln('                    <div class="pub-ads">');
document.writeln('                        <ul>');
document.writeln('                            <li><a target="_blank" href="http://k.kongzhong.com/">口袋密令</a></li>');
document.writeln('                            <li><a target="_blank" href="https://passport.kongzhong.com/billing/pay/payment_bank">点券充值</a></li>');
document.writeln('                            <li><a target="_blank" href="https://passport.kongzhong.com/v/billing/pay/game_bank">游戏直充</a></li>');
document.writeln('                            <li><a target="_blank" href="http://kf.kongzhong.com/">客服中心</a></li>');
document.writeln('                            <li><a target="_blank" href="http://vip.kongzhong.com/">VIP专区</a></li>');
document.writeln('                        </ul>');
document.writeln('                    </div>');
document.writeln('                </div>');
document.writeln('            </div>');
document.writeln('        </div>');
document.writeln('    </div>');
document.writeln('</div>');
if (document.all){
window.attachEvent('onload', pubH_onloadwindow)//IE中
}
else{
window.addEventListener('load',pubH_onloadwindow,false);//firefox
}
//小图轮播
var pubH_turnCount=0;//确定为图片的数量  常数  不改变 n-1
var pubH_scrolltimer=null;
var pubH_scrolltimer2=null;
//moveLeft({className:"smallImages",final:226,speed:2});  传入一个对象参数  className:运动的对象  final:最终值
var pubH_smallTimer=null;
var pubH_smallimgCount=0;

function pubH_onloadwindow(){
    pubH_smallTimer=setTimeout(pubH_smallTurn,0);
 	var menugame = document.getElementById("all_menugame");
	var menuimg = document.getElementById("all_menuimg");
	var menulogin =document.getElementById("menulogin");

	var getcookie = pubH_getCookie("UDT-KZG");
	if (getcookie != "") {
		menulogin.style.display="none";
		var jloginbox = document.getElementById("jloginbox");
		var currenturl = window.location.href;
		jloginbox.innerHTML=
		'<a href="https://passport.kongzhong.com/v/user/userindex" target="_blank" class="menu">'+getcookie+'</a><a href="https://sso.kongzhong.com/logout?service='+currenturl+'" class="menu">退出</a><a href="http://passport.kongzhong.com/v/billing/pay/game_bank" class="menu">充值</a><a href="http://kf.kongzhong.com/" target="_blank" class="menu">客服</a>';
	}

	menugame.onmouseover = function(){
		this.className = "all_menugame_hover";
		//this.getElementsByTagName("dd")[0].style.display = "block";
		//this.getElementsByTagName("dt")[0].style.display = "none";
	}
	menugame.onmouseout = function(){
		this.className = '';
		//this.getElementsByTagName("dd")[0].style.display = "none";
		//this.getElementsByTagName("dt")[0].style.display = "block";
		}
	menuimg.onmouseover = function(){
		this.className = "all_menuimg_hover";
		clearTimeout(pubH_smallTimer);
		this.getElementsByTagName("dd")[0].style.display = "block";
		var bigBox=pubH_getElementsByClassName("bigpic")[0];
		bigBox.children[pubH_smallimgCount].style.display = "block";
		this.getElementsByTagName("dt")[0].style.display = "none";
	}
	menuimg.onmouseout = function(){
		this.className = "";
		pubH_smallTimer=setTimeout(pubH_smallTurn,100);
		this.getElementsByTagName("dd")[0].style.display = "none";
		this.getElementsByTagName("dt")[0].style.display = "block";
        var bigBox=pubH_getElementsByClassName("bigpic")[0];
		bigBox.children[pubH_smallimgCount].style.display = "none";
	}
}
function pubH_getElementsByClassName(className,node){            //通过类名获取元素,返回一个元素数组
    node = node || document;
    if(node.getElementsByClassName){
        return node.getElementsByClassName(className);
    }
    var eles = node.getElementsByTagName('*');
    var reg = [];
    for(var i = 0,l = eles.length; i < l; i++){
        if(pubH_hasOrNotClass(className,eles[i])){
            reg.push(eles[i]);
        }
    }
    return reg;
}
function pubH_hasOrNotClass(className,node){             //判断是否含有某类名
    var eles = node.className.split(/\s+/);
    for(var i = 0,l = eles.length; i < l; i++){
        if(eles[i] == className){
            return true;
        }
    }
    return false;
}

function pubH_fixEvt(evt){                       //处理事件的兼容性
    evt = evt || window.event;
    if(!evt.pageX){
        evt.pageX = evt.clientX + document.documentElement.scrollLeft - 2;
        evt.pageY = evt.clientY + document.documentElement.scrollTop - 2;
    }
    return evt;
}

function pubH_getCookie(c_name){
	if(document.cookie.length>0){
	   c_start=document.cookie.indexOf(c_name + "=")
	   if(c_start!=-1){
		 c_start=c_start + c_name.length+1
		 c_end=document.cookie.indexOf(";",c_start)
		 if(c_end==-1) c_end=document.cookie.length
		 return pubH_hidename(unescape(document.cookie.substring(c_start,c_end)))
	   }
	}
	return ""
}
function pubH_hidename(name){
	var RegCellPhone = /^([0-9]{11})?$/;
	var hideString='******';
	if(name==""){
		return "";
	}
	if(name.search(RegCellPhone)>-1){
		var phoneuser = name.substring(0,3)+"****"+name.substring(7,11);
		return phoneuser;
	}
	if(name.indexOf('@')>-1){
		var emailarray = name.split('@');
		var emailname = emailarray[0];
		if(emailname.length<6){
			emailname = emailname.substring(0,1)+hideString.substring(0,emailname.length-2)+emailname.substring(emailname.length-1,emailname.length);
		}else{
			emailname = emailname.substring(0,1)+"****"+emailname.substring(emailname.length-1,emailname.length);
		}
		var emailuser = emailname +"@"+emailarray[1];
		return emailuser;
	}else{
		if(name.length<6){
			name = name.substring(0,1)+hideString.substring(0,name.length-2)+name.substring(name.length-1,name.length);
		}else{
			name = name.substring(0,1)+"****"+name.substring(name.length-2,name.length);
		}
		return name;
	}
}
function pubH_urljump() {
	window.location.href="http://passport.kongzhong.com/login?backurl="+window.location.href;
	return;
}
function pubH_smallTurn(){
	clearTimeout(pubH_scrolltimer);
	clearTimeout(pubH_smallTimer);
	if(pubH_smallimgCount>=pubH_turnCount){
		pubH_smallimgCount=0
		var final=pubH_smallimgCount*43;
		pubH_moveTop({className:"smallImages",final:final,speed:1});
		pubH_smallTimer=setTimeout(pubH_smallTurn,500);
		}
	else{
	    pubH_smallimgCount++;
		var final=pubH_smallimgCount*43;
		pubH_moveTop({className:"smallImages",final:final,speed:1});
		pubH_smallTimer=setTimeout(pubH_smallTurn,5000);
		}
	}
function pubH_moveTop(obj){
	var nodeClass=pubH_getElementsByClassName(obj.className)[0];
	var final=obj.final;
	var speed=obj.speed;
	var start=Math.abs(parseInt(nodeClass.style.marginTop));
	if(!start){
		start=0;
		}
	pubH_scrolltimer=setTimeout(scrollLeft,1);
	function scrollLeft(){
		if(final==0){
			nodeClass.style.marginTop="0px";
			return;
			}
		nodeClass.style.marginTop="-"+start+"px";
		start+=speed;
		if(start<=final){
		    timer=setTimeout(scrollLeft,1);
		}
		 else{
			 start=final;
			 clearTimeout(pubH_scrolltimer);
			 }
		}
}













